import io
import sys
import unittest


class GeneralTest(unittest.TestCase):
    def test_names_1(self):
        """
        PyErr_Display() will offer suggestions of similar variable
        names in the function that the exception was raised from
        """
        paper = 5

        try:
            sys.stderr = open("error_date/name_error.txt", encoding="locale", mode="w")

        finally:
            sys.stderr.close()
            sys.stderr = sys.__stderr__


if __name__ == "__main__":
    unittest.main()